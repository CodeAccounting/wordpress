<?php

class provide_productArchive_Settings
{
    public $icon;
    public $id;
    public $title;
    public $desc;

    public function __construct()
    {
        $this->icon = '';
        $this->id = 'productArchive';
        $this->title = esc_html__('Product Archive Style', 'provide');
        $this->desc = esc_html__('Woocommerce products Settings', 'provide');
    }

    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }
    }

    public function __set($property, $value)
    {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
    }

    public function provide_init()
    {
        return array(
            array(
                'id' => 'optProductArchive',
                'type' => 'select',
                'title' => esc_html__('Select Product Column', 'provide'),
                'options' => array(
                    'col-md-6' => esc_html__('2 Col', 'provide'),
                    'col-md-4' => esc_html__('3 Col', 'provide'),
                    'col-md-3' => esc_html__('4 Col', 'provide')
                )
            ),
        );
    }

}

<!DOCTYPE html>
<html class="no-js" <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="profile" href="http://gmpg.org/xfn/11">
        <link rel="pingback" href="<?php esc_url(bloginfo('pingback_url')); ?>">
        <?php
        $h = new provide_Helper;
        $opt = $h->provide_opt();
        $logo = $h->provide_set($opt, 'optHeaderSixLogo');
        
        wp_head();
        $boxed = ( $h->provide_set($opt, 'themeBoxedLayout') == '1' ) ? 'boxed' : '';
        provide_Media::provide_singleton()->provide_eq(array('smoothscroll'));
        
        $script = '
            jQuery(document).ready(function() {
                jQuery("html").smoothScroll(300);
            });
        ';
        wp_add_inline_script("smoothscroll", $script);
        ?>
        
    </head>
    <body <?php body_class(); ?>>
        <div class="theme-layout <?php echo esc_attr($boxed) ?>">
            
            <header class="onepage-header">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="logo">
                                <?php
                                if ($h->provide_set($logo, 'url') == ''):
                                    if (is_front_page() && is_home()) :
                                        ?>
                                        <h1>
                                            <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
                                        </h1>
                                    <?php else : ?>
                                        <p>
                                            <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
                                        </p>
                                    <?php
                                    endif;
                                else:
                                    ?>
                                    <a href="<?php echo esc_url(home_url('/')) ?>" title="">
                                        <img src="<?php echo esc_url($h->provide_set($logo, 'url')) ?>" alt=""/>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="onpage-menu">
                                <?php wp_nav_menu(array('theme_location' => 'primary', 'menu_class'=>'', 'container'=>false)); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </header>